﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tinhtienduavaotuoi;
using System;

namespace TinhtienTester
{
    [TestClass]
    public class UnitTest1
    {
        // 1
        [TestMethod]
        public void Child_Age_0()
        {
            Assert.AreEqual(50, Form1.Tinh("Child", 0));
        }

        // 2
        [TestMethod]
        public void Child_Age_17()
        {
            Assert.AreEqual(50, Form1.Tinh("Child", 17));
        }

        // 3
        [TestMethod]
        public void Child_Age_18_Invalid()
        {
            Form1.Tinh("Child", 18);
        }

        // 4
        [TestMethod]
        public void Male_18()
        {
            Assert.AreEqual(100, Form1.Tinh("Male", 18));
        }

        // 5
        [TestMethod]
        public void Male_35()
        {
            Assert.AreEqual(100, Form1.Tinh("Male", 35));
        }

        // 6
        [TestMethod]
        public void Male_36()
        {
            Assert.AreEqual(120, Form1.Tinh("Male", 36));
        }

        // 7
        [TestMethod]
        public void Male_50()
        {
            Assert.AreEqual(120, Form1.Tinh("Male", 50));
        }

        // 8
        [TestMethod]
        public void Male_51()
        {
            Assert.AreEqual(140, Form1.Tinh("Male", 51));
        }

        // 9
        [TestMethod]
        public void Female_18()
        {
            Assert.AreEqual(80, Form1.Tinh("Female", 18));
        }

        // 10
        [TestMethod]
        public void Female_35()
        {
            Assert.AreEqual(80, Form1.Tinh("Female", 35));
        }

        // 11
        [TestMethod]
        public void Female_36()
        {
            Assert.AreEqual(110, Form1.Tinh("Female", 36));
        }

        // 12
        [TestMethod]
        public void Female_50()
        {
            Assert.AreEqual(110, Form1.Tinh("Female", 50));
        }

        // 13
        [TestMethod]
        public void Female_51()
        {
            Assert.AreEqual(140, Form1.Tinh("Female", 51));
        }

        // 14
        [TestMethod]
        public void Age_Negative()
        {
            Form1.Tinh("Male", -1);
        }

        // 15
        [TestMethod]
        public void Age_Over_145()
        {
            Form1.Tinh("Female", 146);
        }

        // 16
        [TestMethod]
        public void Invalid_Type()
        {
            Form1.Tinh("ABC", 20);
        }

        // 17
        [TestMethod]
        public void Empty_Type()
        {
            Form1.Tinh("", 20);
        }

        // 18
        [TestMethod]
        public void Null_Type()
        {
            Form1.Tinh(null, 20);
        }

        // 19
        [TestMethod]
        public void Child_Age_10()
        {
            Assert.AreEqual(50, Form1.Tinh("Child", 10));
        }

        // 20
        [TestMethod]
        public void Male_Max_Age()
        {
            Assert.AreEqual(140, Form1.Tinh("Male", 145));
        }

        // 21. Child – age > 17 (fail)
        [TestMethod]
        public void Child_Age_20_Fail()
        {
            Form1.Tinh("Child", 20);
        }

        // 22. Male – age < 18 (fail)
        [TestMethod]
        public void Male_Age_17_Fail()
        {
            Form1.Tinh("Male", 17);
        }

        // 23. Female – age < 18 (fail)
        [TestMethod]
        public void Female_Age_10_Fail()
        {
            Form1.Tinh("Female", 10);
        }

    }
}
