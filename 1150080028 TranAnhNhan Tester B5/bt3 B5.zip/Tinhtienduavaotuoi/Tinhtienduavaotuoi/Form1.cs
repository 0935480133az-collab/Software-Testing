﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tinhtienduavaotuoi
{
    public partial class Form1 : Form
    {

public static int Tinh(string type, int age)
        {
            if (age < 0 || age > 145)
                throw new ArgumentException();

            if (type == "Child")
            {
                if (age <= 17) return 50;
                throw new ArgumentException();
            }

            if (type == "Male")
            {
                if (age < 18) throw new ArgumentException();
                if (age <= 35) return 100;
                if (age <= 50) return 120;
                return 140;
            }

            if (type == "Female")
            {
                if (age < 18) throw new ArgumentException();
                if (age <= 35) return 80;
                if (age <= 50) return 110;
                return 140;
            }

            throw new ArgumentException();
        }

        private void txtPayment_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
