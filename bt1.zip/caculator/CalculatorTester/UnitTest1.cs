﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PowerApp;
using System;

namespace CalculatorTester
{
    [TestClass]
    public class UnitTest1
    {
        private HamPower p;

        [TestInitialize]
        public void SetUp()
        {
            this.p = new HamPower(2, 3);
        }

        [TestMethod]
        public void TestNEquals0()
        {
            HamPower p = new HamPower(5, 0);
            Assert.AreEqual(1.0, p.Execute());
        }

        [TestMethod]
        public void TestPositiveN()
        {
            HamPower p = new HamPower(2, 3);
            Assert.AreEqual(8.0, p.Execute());
        }

        [TestMethod]
        public void TestNegativeN()
        {
            HamPower p = new HamPower(2, -2);
            Assert.AreEqual(0.25, p.Execute());
        }

        [TestMethod]
        public void TestXEquals1()
        {
            HamPower p = new HamPower(1, 50);
            Assert.AreEqual(1.0, p.Execute());
        }

        [TestMethod]
        public void TestXEquals0()
        {
            HamPower p = new HamPower(0, 5);
            Assert.AreEqual(0.0, p.Execute());
        }

        [TestMethod]
        public void TestNegativeX_OddN()
        {
            HamPower p = new HamPower(-2, 3);
            Assert.AreEqual(-8.0, p.Execute());
        }

        [TestMethod]
        public void TestNegativeX_EvenN()
        {
            HamPower p = new HamPower(-2, 4);
            Assert.AreEqual(16.0, p.Execute());
        }

        [TestMethod]
        public void TestNEquals1()
        {
            HamPower p = new HamPower(9, 1);
            Assert.AreEqual(9.0, p.Execute());
        }

        [TestMethod]
        public void TestNEqualsMinus1()
        {
            HamPower p = new HamPower(2, -1);
            Assert.AreEqual(0.5, p.Execute());
        }

        [TestMethod]
        public void TestRealNumber()
        {
            HamPower p = new HamPower(1.5, 2);
            Assert.AreEqual(2.25, p.Execute(), 0.0001);
        }

        [TestMethod]
        public void TestLargeN()
        {
            HamPower p = new HamPower(2, 5);
            Assert.AreEqual(32.0, p.Execute());
        }

        [TestMethod]
        public void TestNegativeBaseEven()
        {
            HamPower p = new HamPower(-3, 2);
            Assert.AreEqual(9.0, p.Execute());
        }

        [TestMethod]
        public void TestNegativeBaseOdd()
        {
            HamPower p = new HamPower(-3, 3);
            Assert.AreEqual(-27.0, p.Execute());
        }

        [TestMethod]
        public void TestFractionBase()
        {
            HamPower p = new HamPower(0.5, 2);
            Assert.AreEqual(0.25, p.Execute(), 0.0001);
        }

        [TestMethod]
        public void TestOnePower()
        {
            HamPower p = new HamPower(100, 1);
            Assert.AreEqual(100.0, p.Execute());
        }
    }
}