﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PowerApp
{
    public class HamPower
    {
        private double x;
        private int n;

        public HamPower(double x, int n)
        {
            this.x = x;
            this.n = n;
        }

        public double Execute()
        {
            return Tinh(x, n);
        }

        private double Tinh(double x, int n)
        {
            if (n == 0)
                return 1.0;

            else if (n > 0)
                return x * Tinh(x, n - 1);   

            else
                return Tinh(x, n + 1) / x;
        }
    }
}

