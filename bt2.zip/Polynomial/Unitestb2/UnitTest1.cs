﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Polynomial;
using System;
using System.Collections.Generic;
namespace Unitestb2
{
    [TestClass]
    public class UnitTest1
    {
        private Polynomials p;

        [TestInitialize]
        public void SetUp()
        {
            p = new Polynomials(2, new List<int> { 1, 2, 3 });
        }

        // 1. x = 0
        [TestMethod]
        public void TestXEquals0()
        {
            Polynomials p = new Polynomials(2, new List<int> { 5, 4, 3 });
            Assert.AreEqual(5, p.Cal(0));
        }

        // 2. x = 1
        [TestMethod]
        public void TestXEquals1()
        {
            Polynomials p = new Polynomials(2, new List<int> { 1, 2, 3 });
            Assert.AreEqual(6, p.Cal(1));
        }

        // 3. x = 2
        [TestMethod]
        public void TestXEquals2()
        {
            Polynomials p = new Polynomials(2, new List<int> { 1, 2, 1 });
            Assert.AreEqual(9, p.Cal(2));
        }

        // 4. x âm
        [TestMethod]
        public void TestNegativeX()
        {
            Polynomials p = new Polynomials(2, new List<int> { 1, 0, 1 });
            Assert.AreEqual(5, p.Cal(-2));
        }

        // 5. bậc 1
        [TestMethod]
        public void TestLinear()
        {
            Polynomials p = new Polynomials(1, new List<int> { 1, 2 });
            Assert.AreEqual(3, p.Cal(1));
        }

        // 6. đa thức hằng
        [TestMethod]
        public void TestConstant()
        {
            Polynomials p = new Polynomials(0, new List<int> { 7 });
            Assert.AreEqual(7, p.Cal(100));
        }

        // 7. hệ số 0
        [TestMethod]
        public void TestZeroCoeff()
        {
            Polynomials p = new Polynomials(2, new List<int> { 0, 0, 5 });
            Assert.AreEqual(20, p.Cal(2));
        }

        // 8. hệ số âm
        [TestMethod]
        public void TestNegativeCoeff()
        {
            Polynomials p = new Polynomials(1, new List<int> { -1, 2 });
            Assert.AreEqual(1, p.Cal(1));
        }

        // 9. bậc 3
        [TestMethod]
        public void TestCubic()
        {
            Polynomials p = new Polynomials(3, new List<int> { 1, 1, 1, 1 });
            Assert.AreEqual(4, p.Cal(1));
        }

        // 10. x = -1
        [TestMethod]
        public void TestXMinus1()
        {
            Polynomials p = new Polynomials(2, new List<int> { 1, 2, 3 });
            Assert.AreEqual(2, p.Cal(-1));
        }

        // 11. x thực (bị ép int)
        [TestMethod]
        public void TestRealX()
        {
            Polynomials p = new Polynomials(1, new List<int> { 1, 1 });
            Assert.AreEqual(2, p.Cal(1.5));
        }

        // 12. bậc 4
        [TestMethod]
        public void TestDegree4()
        {
            Polynomials p = new Polynomials (4, new List<int> { 1, 1, 1, 1, 1 });
            Assert.AreEqual(5, p.Cal(1));
        }

        // 13. hệ số lớn
        [TestMethod]
        public void TestLargeCoeff()
        {
            Polynomials p = new Polynomials(1, new List<int> { 10, 10 });
            Assert.AreEqual(20, p.Cal(1));
        }

        // 14. nhiều hệ số
        [TestMethod]
        public void TestAllOnes()
        {
            Polynomials p = new Polynomials(3, new List<int> { 1, 1, 1, 1 });
            Assert.AreEqual(15, p.Cal(2));
        }

        // 15. dữ liệu sai
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestInvalidInput()
        {
            Polynomials p = new Polynomials(5, new List<int> { 1, 2 });
        }
    }
}