﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Doisonguyen;
using System;

namespace RadixTester
{
    [TestClass]
    public class UnitTestRadix
    {
        private Radix r;

        [TestInitialize]
        public void SetUp()
        {
            r = new Radix(10);
        }

        [TestMethod]
        public void TestBinary_10()
        {
            Radix r = new Radix(10);
            Assert.AreEqual("1010", r.ConvertDecimalToAnother(2));
        }

        [TestMethod]
        public void TestBinary_1()
        {
            Radix r = new Radix(1);
            Assert.AreEqual("1", r.ConvertDecimalToAnother(2));
        }

        [TestMethod]
        public void TestBinary_0()
        {
            Radix r = new Radix(0);
            Assert.AreEqual("", r.ConvertDecimalToAnother(2));
        }

        [TestMethod]
        public void TestOctal_8()
        {
            Radix r = new Radix(8);
            Assert.AreEqual("10", r.ConvertDecimalToAnother(8));
        }

        [TestMethod]
        public void TestOctal_64()
        {
            Radix r = new Radix(64);
            Assert.AreEqual("100", r.ConvertDecimalToAnother(8));
        }

        [TestMethod]
        public void TestHex_10()
        {
            Radix r = new Radix(10);
            Assert.AreEqual("A", r.ConvertDecimalToAnother(16));
        }

        [TestMethod]
        public void TestHex_15()
        {
            Radix r = new Radix(15);
            Assert.AreEqual("F", r.ConvertDecimalToAnother(16));
        }

        [TestMethod]
        public void TestHex_16()
        {
            Radix r = new Radix(16);
            Assert.AreEqual("10", r.ConvertDecimalToAnother(16));
        }

        [TestMethod]
        public void TestHex_255()
        {
            Radix r = new Radix(255);
            Assert.AreEqual("FF", r.ConvertDecimalToAnother(16));
        }

        [TestMethod]
        public void TestBase3_5()
        {
            Radix r = new Radix(5);
            Assert.AreEqual("12", r.ConvertDecimalToAnother(3));
        }

        [TestMethod]
        public void TestBase4_20()
        {
            Radix r = new Radix(20);
            Assert.AreEqual("110", r.ConvertDecimalToAnother(4));
        }

        [TestMethod]
        public void TestBase5_25()
        {
            Radix r = new Radix(25);
            Assert.AreEqual("100", r.ConvertDecimalToAnother(5));
        }

        [TestMethod]
        public void TestBase7_49()
        {
            Radix r = new Radix(49);
            Assert.AreEqual("100", r.ConvertDecimalToAnother(7));
        }

        [TestMethod]
        public void TestBase9_81()
        {
            Radix r = new Radix(81);
            Assert.AreEqual("100", r.ConvertDecimalToAnother(9));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestInvalidRadix_1()
        {
            Radix r = new Radix(10);
            r.ConvertDecimalToAnother(1);
        }
    }
}
