﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HinhHoc
{
    // Lớp Điểm
    public class Diem
    {
        public double X { get; set; }
        public double Y { get; set; }

        public Diem(double x, double y)
        {
            X = x;
            Y = y;
        }
    }

    // Lớp Hình chữ nhật
    public class HinhChuNhat
    {
        public Diem TrenTrai { get; set; }
        public Diem DuoiPhai { get; set; }

        public HinhChuNhat(Diem trenTrai, Diem duoiPhai)
        {
            TrenTrai = trenTrai;
            DuoiPhai = duoiPhai;
        }

        // Tính diện tích
        public double DienTich()
        {
            double chieuDai = Math.Abs(DuoiPhai.X - TrenTrai.X);
            double chieuRong = Math.Abs(TrenTrai.Y - DuoiPhai.Y);
            return chieuDai * chieuRong;
        }

        // Kiểm tra giao nhau
        public bool GiaoNhau(HinhChuNhat hcn)
        {
            if (this.DuoiPhai.X < hcn.TrenTrai.X ||
                this.TrenTrai.X > hcn.DuoiPhai.X ||
                this.TrenTrai.Y < hcn.DuoiPhai.Y ||
                this.DuoiPhai.Y > hcn.TrenTrai.Y)
                return false;

            return true;
        }
    }
}
