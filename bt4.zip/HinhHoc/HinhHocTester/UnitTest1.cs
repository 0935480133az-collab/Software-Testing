﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using HinhHoc;
using System;

namespace HinhHocTester
{
    [TestClass]
    public class UnitTestHCN
    {
        // ===== TEST DIỆN TÍCH (7 test) =====

        [TestMethod]
        public void Area_Normal()
        {
            var h = new HinhChuNhat(new Diem(0, 10), new Diem(5, 0));
            Assert.AreEqual(50, h.DienTich());
        }

        [TestMethod]
        public void Area_UnitSquare()
        {
            var h = new HinhChuNhat(new Diem(0, 1), new Diem(1, 0));
            Assert.AreEqual(1, h.DienTich());
        }

        [TestMethod]
        public void Area_Rectangle()
        {
            var h = new HinhChuNhat(new Diem(2, 8), new Diem(6, 3));
            Assert.AreEqual(20, h.DienTich());
        }

        [TestMethod]
        public void Area_NegativeCoordinates()
        {
            var h = new HinhChuNhat(new Diem(-2, 4), new Diem(2, 0));
            Assert.AreEqual(16, h.DienTich());
        }

        [TestMethod]
        public void Area_ZeroWidth()
        {
            var h = new HinhChuNhat(new Diem(2, 5), new Diem(2, 1));
            Assert.AreEqual(0, h.DienTich());
        }

        [TestMethod]
        public void Area_ZeroHeight()
        {
            var h = new HinhChuNhat(new Diem(1, 3), new Diem(5, 3));
            Assert.AreEqual(0, h.DienTich());
        }

        [TestMethod]
        public void Area_LargeValues()
        {
            var h = new HinhChuNhat(new Diem(0, 1000), new Diem(1000, 0));
            Assert.AreEqual(1_000_000, h.DienTich());
        }

        // ===== TEST GIAO NHAU (8 test) =====

        [TestMethod]
        public void Intersect_True()
        {
            var h1 = new HinhChuNhat(new Diem(0, 10), new Diem(5, 0));
            var h2 = new HinhChuNhat(new Diem(3, 8), new Diem(7, 2));
            Assert.IsTrue(h1.GiaoNhau(h2));
        }

        [TestMethod]
        public void Intersect_False_Left()
        {
            var h1 = new HinhChuNhat(new Diem(0, 5), new Diem(2, 0));
            var h2 = new HinhChuNhat(new Diem(3, 5), new Diem(5, 0));
            Assert.IsFalse(h1.GiaoNhau(h2));
        }

        [TestMethod]
        public void Intersect_False_Above()
        {
            var h1 = new HinhChuNhat(new Diem(0, 5), new Diem(5, 0));
            var h2 = new HinhChuNhat(new Diem(0, 10), new Diem(5, 6));
            Assert.IsFalse(h1.GiaoNhau(h2));
        }

        [TestMethod]
        public void Intersect_Inside()
        {
            var h1 = new HinhChuNhat(new Diem(0, 10), new Diem(10, 0));
            var h2 = new HinhChuNhat(new Diem(2, 8), new Diem(5, 3));
            Assert.IsTrue(h1.GiaoNhau(h2));
        }

        [TestMethod]
        public void Intersect_TouchEdge()
        {
            var h1 = new HinhChuNhat(new Diem(0, 5), new Diem(5, 0));
            var h2 = new HinhChuNhat(new Diem(5, 5), new Diem(10, 0));
            Assert.IsTrue(h1.GiaoNhau(h2));
        }

        [TestMethod]
        public void Intersect_SameRectangle()
        {
            var h1 = new HinhChuNhat(new Diem(0, 5), new Diem(5, 0));
            var h2 = new HinhChuNhat(new Diem(0, 5), new Diem(5, 0));
            Assert.IsTrue(h1.GiaoNhau(h2));
        }

        [TestMethod]
        public void Intersect_FarAway()
        {
            var h1 = new HinhChuNhat(new Diem(0, 5), new Diem(5, 0));
            var h2 = new HinhChuNhat(new Diem(20, 30), new Diem(25, 10));
            Assert.IsFalse(h1.GiaoNhau(h2));
        }

        [TestMethod]
        public void Intersect_PartialOverlap()
        {
            var h1 = new HinhChuNhat(new Diem(0, 5), new Diem(5, 0));
            var h2 = new HinhChuNhat(new Diem(4, 6), new Diem(8, 2));
            Assert.IsTrue(h1.GiaoNhau(h2));
        }
    }
}
