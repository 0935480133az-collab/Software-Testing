﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JUnitMessage
{
    public class message
    {
        private string me;

        // Constructor để khởi tạo đối tượng với giá trị message
        public message(string msg)
        {
            me = msg;
        }

        // Phương thức in thông điệp ra màn hình và gây lỗi chia cho 0
        public void PrintMessage()
        {
            Console.WriteLine(me);
            throw new DivideByZeroException("Lỗi chia cho 0");
        }

        // Phương thức in thông điệp đã thay đổi, thêm "Hi!"
        public string PrintHiMessage()
        {
            me = "Hi! " + me;
            Console.WriteLine(me);
            return me;
        }

        // Phương thức sắp xếp mảng số nguyên
        public static int[] SortArray(int[] array)
        {
            Array.Sort(array);
            return array;
        }

        // Phương thức tìm kiếm phần tử trong mảng số nguyên
        public static int SearchElement(int[] array, int element)
        {
            return Array.IndexOf(array, element);
        }

        // Phương thức tìm kiếm chuỗi trong mảng chuỗi
        public static string SearchElement(string[] array, string element)
        {
            int result = Array.IndexOf(array, element);
            return result >= 0 ? "Found" : "Not Found";
        }

        // Phương thức chuyển đổi từ hệ thập phân sang cơ số khác (2 đến 36)
        public string ConvertDecimalToAnother(int baseNum)
        {
            if (baseNum < 2 || baseNum > 36)
            {
                throw new ArgumentException("Base must be between 2 and 36");
            }

            int number = Convert.ToInt32(this.me);
            string result = "";
            while (number > 0)
            {
                int remainder = number % baseNum;
                result = remainder.ToString() + result;
                number = number / baseNum;
            }
            return result;
        }
    }
}