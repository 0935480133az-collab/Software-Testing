﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using JunitMessage;
using System;
using JUnitMessage;

namespace messagetester
{
    [TestClass]
    public class UnitTestMessage
    {
        private message m;

        // Thiết lập ban đầu
        [TestInitialize]
        public void SetUp()
        {
            m = new message("10");
        }

        // 1. Test phương thức PrintMessage (kiểm tra ngoại lệ chia cho 0)
        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException))]
        public void TestPrintMessage()
        {
            // Act
            m.PrintMessage(); // Phép chia cho 0 gây lỗi
        }

        // 2. Test phương thức PrintHiMessage
        [TestMethod]
        public void TestPrintHiMessage()
        {
            // Arrange
            string expectedMessage = "Hi! 10";

            // Act
            string result = m.PrintHiMessage();

            // Assert
            Assert.AreEqual(expectedMessage, result);
        }

        // 3. Test phương thức SortArray với mảng số nguyên
        [TestMethod]
        public void TestSortArray_Integers()
        {
            // Arrange
            int[] inputArray = { 5, 2, 8, 3 };
            int[] expectedArray = { 2, 3, 5, 8 };

            // Act
            int[] result = message.SortArray(inputArray);  // Gọi phương thức static qua tên lớp

            // Assert
            CollectionAssert.AreEqual(expectedArray, result);
        }

        // 4. Test phương thức SortArray với mảng số nguyên có một phần tử
        [TestMethod]
        public void TestSortArray_SingleElement()
        {
            // Arrange
            int[] inputArray = { 10 };
            int[] expectedArray = { 10 };

            // Act
            int[] result = message.SortArray(inputArray);  // Gọi phương thức static qua tên lớp

            // Assert
            CollectionAssert.AreEqual(expectedArray, result);
        }

        // 5. Test phương thức SortArray với mảng trống
        [TestMethod]
        public void TestSortArray_EmptyArray()
        {
            // Arrange
            int[] inputArray = { };
            int[] expectedArray = { };

            // Act
            int[] result = message.SortArray(inputArray);  // Gọi phương thức static qua tên lớp

            // Assert
            CollectionAssert.AreEqual(expectedArray, result);
        }

        // 6. Test phương thức SearchElement tìm phần tử có trong mảng
        [TestMethod]
        public void TestSearchElement_Found()
        {
            // Arrange
            int[] inputArray = { 5, 2, 8, 3 };
            int elementToSearch = 3;
            int expectedIndex = 3;

            // Act
            int result = message.SearchElement(inputArray, elementToSearch);  // Gọi phương thức static qua tên lớp

            // Assert
            Assert.AreEqual(expectedIndex, result);
        }

        // 7. Test phương thức SearchElement tìm phần tử không có trong mảng
        [TestMethod]
        public void TestSearchElement_NotFound()
        {
            // Arrange
            int[] inputArray = { 5, 2, 8, 3 };
            int elementToSearch = 10;
            int expectedIndex = -1;

            // Act
            int result = message.SearchElement(inputArray, elementToSearch);  // Gọi phương thức static qua tên lớp

            // Assert
            Assert.AreEqual(expectedIndex, result);
        }

        // 8. Test phương thức SearchElement với mảng chuỗi
        [TestMethod]
        public void TestSearchStringElement_Found()
        {
            // Arrange
            string[] inputArray = { "apple", "banana", "cherry" };
            string elementToSearch = "banana";
            string expectedResult = "Found";

            // Act
            string result = message.SearchElement(inputArray, elementToSearch);  // Gọi phương thức static qua tên lớp

            // Assert
            Assert.AreEqual(expectedResult, result);
        }

        // 9. Test phương thức SearchElement với mảng chuỗi không có phần tử
        [TestMethod]
        public void TestSearchStringElement_NotFound()
        {
            // Arrange
            string[] inputArray = { "apple", "banana", "cherry" };
            string elementToSearch = "orange";
            string expectedResult = "Not Found";

            // Act
            string result = message.SearchElement(inputArray, elementToSearch);  // Gọi phương thức static qua tên lớp

            // Assert
            Assert.AreEqual(expectedResult, result);
        }

        // 10. Test phương thức SearchElement với mảng trống
        [TestMethod]
        public void TestSearchElement_EmptyArray()
        {
            // Arrange
            int[] inputArray = { };
            int elementToSearch = 5;
            int expectedIndex = -1;

            // Act
            int result = message.SearchElement(inputArray, elementToSearch);  // Gọi phương thức static qua tên lớp

            // Assert
            Assert.AreEqual(expectedIndex, result);
        }

        // 11. Test kiểm tra chuyển đổi từ số thập phân sang nhị phân
        [TestMethod]
        public void TestConvertDecimalToBinary()
        {
            // Arrange
            string expectedBinary = "1010";

            // Act
            string result = m.ConvertDecimalToAnother(2);  // Gọi phương thức chuyển đổi

            // Assert
            Assert.AreEqual(expectedBinary, result);
        }

        // 12. Test kiểm tra chuyển đổi từ số thập phân sang hệ cơ số 8
        [TestMethod]
        public void TestConvertDecimalToOctal()
        {
            // Arrange
            string expectedOctal = "10";

            // Act
            string result = m.ConvertDecimalToAnother(8);  // Gọi phương thức chuyển đổi

            // Assert
            Assert.AreEqual(expectedOctal, result);
        }

        // 13. Test kiểm tra chuyển đổi từ số thập phân sang hệ cơ số 16
        [TestMethod]
        public void TestConvertDecimalToHexadecimal()
        {
            // Arrange
            string expectedHex = "A";

            // Act
            string result = m.ConvertDecimalToAnother(16);  // Gọi phương thức chuyển đổi

            // Assert
            Assert.AreEqual(expectedHex, result);
        }

        // 14. Test kiểm tra chuyển đổi từ số thập phân sang hệ cơ số 3
        [TestMethod]
        public void TestConvertDecimalToBase3()
        {
            // Arrange
            string expectedBase3 = "12";

            // Act
            string result = m.ConvertDecimalToAnother(3);  // Gọi phương thức chuyển đổi

            // Assert
            Assert.AreEqual(expectedBase3, result);
        }

        // 15. Test phương thức ConvertDecimalToAnother với cơ số không hợp lệ
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestInvalidBase()
        {
            // Act
            m.ConvertDecimalToAnother(1);  // Cơ số 1 không hợp lệ
        }
    }
}