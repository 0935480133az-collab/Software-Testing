﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using person;

namespace Personteser
{
    [TestClass]
    public class PersonTest
    {
        // 1. Test sử dụng ExpectedException để kiểm tra IllegalArgumentException
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestExpectedException()
        {
            new PersonT("Fpoly", -1);  // Mong đợi ArgumentException do tuổi âm
        }

        // 2. Test sử dụng try-catch để kiểm tra IllegalArgumentException
        [TestMethod]
        public void TestExpectedExceptionWithTryCatch()
        {
            try
            {
                new PersonT("Fpoly", -1);  // Kiểm tra ngoại lệ khi tuổi âm
                Assert.Fail("Should have thrown an IllegalArgumentException because age is invalid!");
            }
            catch (ArgumentException e)
            {
                Assert.AreEqual("Invalid age: -1", e.Message);  // Kiểm tra thông điệp ngoại lệ
            }
        }

        // 3. Test với tên hợp lệ và tuổi hợp lệ
        [TestMethod]
        public void TestValidPerson()
        {
            PersonT p = new PersonT("Fpoly", 25);
            Assert.AreEqual("Fpoly", p.Name);
            Assert.AreEqual(25, p.Age);
        }

        // 4. Test với tuổi âm (ExpectedException)
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestNegativeAge()
        {
            new PersonT("Fpoly", -1); // Mong đợi ngoại lệ do tuổi âm
        }

        // 5. Test với tuổi bằng 0
        [TestMethod]
        public void TestZeroAge()
        {
            PersonT p = new PersonT("Fpoly", 0);
            Assert.AreEqual(0, p.Age);
        }

        // 6. Test với tuổi lớn
        [TestMethod]
        public void TestLargeAge()
        {
            PersonT p = new PersonT("Fpoly", 100);
            Assert.AreEqual(100, p.Age);
        }

        // 7. Test với tên null và tuổi hợp lệ (ExpectedException)
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestNullName()
        {
            new PersonT(null, 25);  // Tên là null, mong đợi ArgumentNullException
        }

        // 8. Test với tuổi âm lớn
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestLargeNegativeAge()
        {
            new PersonT("Fpoly", -100);  // Tuổi âm lớn, mong đợi ArgumentException
        }

        // 9. Test với tên rỗng và tuổi hợp lệ (ExpectedException)
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestEmptyName()
        {
            new PersonT("", 30);  // Tên rỗng, mong đợi ArgumentException
        }

        // 10. Test với tuổi hợp lệ và tên hợp lệ
        [TestMethod]
        public void TestValidPersonWithValidAge()
        {
            PersonT p = new PersonT("John", 30);
            Assert.AreEqual("John", p.Name);
            Assert.AreEqual(30, p.Age);
        }

        // 11. Test với tên hợp lệ và tuổi hợp lệ, kiểm tra lại getter methods
        [TestMethod]
        public void TestPersonNameAndAge()
        {
            PersonT p = new PersonT("Alice", 28);
            Assert.AreEqual("Alice", p.Name);
            Assert.AreEqual(28, p.Age);
        }

        // 12. Test với tuổi lớn
        [TestMethod]
        public void TestVeryOldPerson()
        {
            PersonT p = new PersonT("OldMan", 150);
            Assert.AreEqual(150, p.Age);
        }

        // 13. Test với tuổi không đúng kỳ vọng
        [TestMethod]
        public void TestFailedAgeAssertion()
        {
            PersonT p = new PersonT("Fpoly", 25);
            Assert.AreNotEqual(30, p.Age);  // Kiểm tra rằng tuổi không phải là 30
        }

        // 14. Test với tuổi hợp lệ và tên hợp lệ, kiểm tra độ dài tên
        [TestMethod]
        public void TestNameLength()
        {
            PersonT p = new PersonT("Fpoly", 20);
            Assert.IsTrue(p.Name.Length > 3);  // Kiểm tra rằng tên có độ dài lớn hơn 3 ký tự
        }

        // 15. Test với tên hợp lệ và tuổi hợp lệ, kiểm tra giá trị tuổi hợp lệ
        [TestMethod]
        public void TestAgeRange()
        {
            PersonT p = new PersonT("Bob", 40);
            Assert.IsTrue(p.Age >= 0 && p.Age <= 150);  // Kiểm tra rằng tuổi hợp lệ trong khoảng từ 0 đến 150
        }
    }
}