﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace person
{
    public class PersonT
    {
        private readonly string name;
        private readonly int age;

        // Constructor
        public PersonT(string name, int age)
        {
            this.name = name;
            this.age = age;

            if (age < 0)
            {
                throw new ArgumentException("Invalid age: " + age);
            }
        }

        // Getter methods
        public string Name => name;
        public int Age => age;
    }
}